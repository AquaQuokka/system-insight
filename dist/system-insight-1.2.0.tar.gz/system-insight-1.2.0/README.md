# System Insight Tool

A simple tool for quickly gathering information about the current state of the system.


## Planned Features

- Faster performance. (Not a priority, but it is a little slow currently.)
- A proper CLI for gathering just the information you need.
- Support for other operating systems.
- More information about the system.
- Better formatting.